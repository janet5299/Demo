package com.example.demo.repository;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import com.example.demo.model.Address;

@Repository
	public class AddressRepository {
	    private List<Address> list = new ArrayList<Address>(Arrays.asList(
	                new Address(1, "123 jalan 123", "Perak"),
	                new Address(2, "223 jalan 223", "Selangor"),
	                new Address(3, "333 jalan 333", "Penang")));
	  
	    public List<Address> getAllAddress() {
	        return list;
	    }
	    
	    public Address findById(int id){
	        for (int i = 0; i < list.size(); i++) {
	            if (list.get(i).getId() == (id)) {
	                return list.get(i);
	            }
	        }
	        return null;
	    }
}

