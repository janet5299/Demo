// Java Program to Illustrate DemoController

// Importing package to code module
package com.example.demo.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Address;
import com.example.demo.service.AddressService;

// Annotation
@RestController
@RequestMapping("/address")
public class DemoController {

	@Autowired
    private AddressService service;

    @GetMapping
    public List<Address> findAllAddress() {
        return service.getAddress();
    }
    
    @GetMapping("{id}")
    public Address findEmployeeById(@PathVariable int id) {
    	
    	Address addr = service.getAddressById(id);

        return addr;
    }
}
