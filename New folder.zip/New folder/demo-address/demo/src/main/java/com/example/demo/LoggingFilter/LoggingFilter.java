package com.example.demo.LoggingFilter;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

@Component
public class LoggingFilter extends OncePerRequestFilter{
	
	private static final Logger logger = LoggerFactory.getLogger(LoggingFilter.class);
	
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		ContentCachingRequestWrapper reqWrapper = new ContentCachingRequestWrapper(request);
		ContentCachingResponseWrapper respWrapper = new ContentCachingResponseWrapper(response);
		
		long startTime = System.currentTimeMillis();
		
		filterChain.doFilter(reqWrapper, respWrapper);
		
		long endTime = System.currentTimeMillis() - startTime;
		
		String requestBody = getStringValue(reqWrapper.getContentAsByteArray(), request.getCharacterEncoding());
		String responseBody = getStringValue(respWrapper.getContentAsByteArray(), response.getCharacterEncoding());
		
		logger.info("Logs : MRTETHOD = {} ; REQUESTURI = {} ; REQUEST BODY = {} ; RESPONSE CODE = {} ; RESPONSE BODY = {} ; TIME TAKEN = {}", 
				request.getMethod(), request.getRequestURI(),requestBody, response.getStatus(), responseBody, endTime); 
		
		respWrapper.copyBodyToResponse();
	}

	private String getStringValue(byte[] contentAsByteArray, String characterEncoding) {
		try {
			return new String(contentAsByteArray, 0, contentAsByteArray.length,characterEncoding );
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
	
	

}
