// Java Program to Illustrate DemoController

// Importing package to code module
package com.example.demo.controller;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.DemoApplication;
import com.example.demo.model.Address;
import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;

// Annotation
@RestController
@RequestMapping("/employee")
public class DemoController {
	private static final Logger logger = LoggerFactory.getLogger(DemoController.class);
	@Autowired
    private EmployeeService service;

    @PostMapping
    public Employee addEmployee(@RequestBody Employee emp) {
        return service.saveEmployee(emp);
    }

    @GetMapping
    public List<Employee> findAllEmployees() {
        return service.getEmployees();
    }
   /* @GetMapping
    public List<Employee> findAllEmployees(
            @RequestParam(defaultValue = "0") int pageNo,
            @RequestParam(defaultValue = "10") int pageSize) {
      
    	Page<Employee> result = service.findAll(pageNo, pageSize);
        return result.getContent();
    }*/
    @Autowired
    private RestTemplate restTemplate;
    
    @GetMapping("{id}")
    public Employee findEmployeeById(@PathVariable int id) {
    	
    	Employee emp = service.getEmployeeById(id);
    	Address address = this.restTemplate.getForObject("http://localhost:8001/address/" + id, Address.class);
    	emp.setAddress(address);
    	
        return emp;
    }

    @PutMapping
    public Employee updateEmployee(@RequestBody Employee emp) {
        return service.updateEmployee(emp);
    }

    @DeleteMapping("{id}")
    public String deleteEmployee(@PathVariable int id) {
        return service.deleteEmployee(id);
    }
}
