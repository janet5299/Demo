package com.example.demo.repository;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Employee;

@Repository
	public class EmployeeRepository  {
	    private List<Employee> list = new ArrayList<Employee>(Arrays.asList(
	                new Employee(1, "Employee 1", "Manager", null),
	                new Employee(2, "Employee 2", "VP", null),
	                new Employee(3, "Employee 3", "Executive",null)));
	  
	    public List<Employee> getAllEmployees() {
	        return list;
	    }

	    public Employee findById(int id){
	        for (int i = 0; i < list.size(); i++) {
	            if (list.get(i).getId() == (id)) {
	                return list.get(i);
	            }
	        }
	        return null;
	    }

	    public List<Employee> search(String name) {
	        return list.stream().filter(x -> x.getName().startsWith(name)).collect(Collectors.toList());
	    }

	    public Employee save(Employee p) {
	        Employee emp = new Employee();
	        emp.setId(p.getId());
	        emp.setName(p.getName());
	        emp.setDesignation(p.getDesignation());
	        list.add(emp);
	        return emp;
	    }

	    public String delete(Integer id) {
	        list.removeIf(x -> x.getId() == (id));
	        return null;
	    }

	    public Employee update(Employee emp) {
	        int idx = 0;
	        int id = 0;
	        for (int i = 0; i < list.size(); i++) {
	            if (list.get(i).getId() == (emp.getId())) {
	                id = emp.getId();
	                idx = i;
	                break;
	            }
	        }

	        Employee emp1 = new Employee();
	        emp1.setId(id);
	        emp1.setName(emp.getName());
	        emp1.setDesignation(emp.getDesignation());
	        list.set(idx, emp);
	        return emp1;
	    }
}

