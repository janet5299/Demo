package com.example.demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class DemoApplication {

	private static final Logger logger = LoggerFactory.getLogger(DemoApplication.class);
	
	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);

	}
	
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
	
	 /*  @Autowired
	    EmployeeRepository empRepository;

	    @Bean
	    public CommandLineRunner startup() {

	        return args -> {

	            Employee b1 = new Employee(221,
	                    "Employee 1",
	                    "VP", null);
	            Employee b2 = new Employee(2,
	                    "Employee 2",
	                    "VP", null);
	            Employee b3 = new Employee(3,
	                    "Employee 3",
	                    "VP", null);
	            Employee b4 = new Employee(4,
	                    "Employee 4",
	                    "VP", null);
	            Employee b5 = new Employee(5,
	                    "Employee 5",
	                    "VP", null);
 
	             List<Employee> emp = new ArrayList<Employee>(Arrays.asList(b1, b2, b3, b4, b5));
	             for (Employee a:emp) {
	            empRepository.save(a);
	             }

	        };

	    }*/

}
